# ai-telegram-bot

Project structure for AI Telegram Bot.